document.addEventListener("DOMContentLoaded", main);
