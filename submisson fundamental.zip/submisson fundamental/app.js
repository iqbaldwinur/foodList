// import "./src/script/component/app-bar.js";
import main from "./src/script/view/main.js";
import "./src/script/component/app-bar.js";

document.addEventListener("DOMContentLoaded", main);
