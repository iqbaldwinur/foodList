function DataSource(onSuccess, onFailed) {
  this.onSuccess = onSuccess;
  this.onFailed = onFailed;
}

DataSource.prototype.searchfood = function (keyword) {
  var filteredClubs = foods.filter(function (food) {
    return food.strMeal.toUpperCase().includes(keyword.toUpperCase());
  });

  if (filteredClubs.length) {
    this.onSuccess(filteredClubs);
  } else {
    this.onFailed(keyword + " is not found");
  }
};
