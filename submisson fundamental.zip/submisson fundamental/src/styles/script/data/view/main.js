var main = function () {
  var key = document.querySelector("#keyword");
  var submitbtn = document.querySelector("#submitbtn");
  var foodList = document.querySelector("#foodList");

  var onButtonSearchClicked = function () {
    var dataSource = new DataSource(renderResult, fallbackResult);
    dataSource.searchfood(key.value);
  };

  var renderResult = function (results) {
    foodList.innerHTML = "";
    results.forEach(function (food) {
      var strMeal = food.strMeal;
      var strCategory = food.strCategory;
      var strInstructions = food.strInstructions;

      var foodElement = document.createElement("div");
      foodElement.setAttribute("class", "food");

      foodElement.innerHTML =
        '<div class="food-info">\n' +
        "<h2>" +
        strMeal +
        "</h2>\n" +
        "<p>" +
        strCategory +
        "</p>\n" +
        "<p>" +
        strInstructions +
        "<p>" +
        "</div";

      foodList.appendChild(foodElement);
    });
  };

  var fallbackResult = function (message) {
    foodList.innerHTML = "";
    foodList.innerHTML += '<h2 class="placeholder">' + message + "</h2>";
  };

  submitbtn.addEventListener("click", onButtonSearchClicked);
};
