import DataSource from "../data/data-source";

const main = () => {
  const key = document.querySelector("#keyword");
  const submitbtn = document.querySelector("#submitbtn");
  const foodList = document.querySelector("#foodList");

  const onButtonSearchClicked = function () {
    const dataSource = new DataSource(renderResult, fallbackResult);
    dataSource.searchfood(key.value);
  };

  const renderResult = (results) => {
    foodList.innerHTML = "";
    results.forEach(function (food) {
      const { name, stadium, description } = food;

      const foodElement = document.createElement("div");
      foodElement.setAttribute("class", "food");

      foodElement.innerHTML = `
      
      <div class="club-info">
        <h2>${name}</h2>
        <p>${stadium}</p>
        <p>${description}</p>
      </div>`;

      foodList.appendChild(foodElement);
    });
  };

  const fallbackResult = (message) => {
    foodList.innerHTML = "";
    foodList.innerHTML += `<h2 class="placeholder">${message}</h2>`;
  };

  submitbtn.addEventListener("click", onButtonSearchClicked);
};

export default main;
