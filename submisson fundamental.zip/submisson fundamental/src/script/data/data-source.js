import foods from "./foods.js";

class DataSource {
  constructor(onSuccess, onFailed) {
    this.onSuccess = onSuccess;
    this.onFailed = onFailed;
  }
  searchfood(keyword) {
    const filteredfood = foods.filter((food) =>
      food.name.toUpperCase().includes(keyword.toUpperCase())
    );

    if (filteredfood.length) {
      this.onSuccess(filteredfood);
    } else {
      this.onFailed(`${keyword} is not found`);
    }
  }
}
export default DataSource;
